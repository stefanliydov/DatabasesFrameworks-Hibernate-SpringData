package app.exam.domain.dto.json;

public class EmployeeOrdersJSONExportDTO {

}
