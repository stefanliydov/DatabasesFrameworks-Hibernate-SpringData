package app.exam.controller;

import org.springframework.stereotype.Controller;
import java.util.List;

@Controller
public class CategoryController {
    public String getCategoriesWithMostPopularItemsSorted(List<String> categoryNames){
        return null;
    }
}
