package app.exam.controller;

import org.springframework.stereotype.Controller;

@Controller
public class OrdersController {

    public String importDataFromXML(String xmlContent) {
        return null;
    }

    public String exportOrdersByEmployeeAndOrderType(String employeeName, String orderType) {
       return null;
    }
}
