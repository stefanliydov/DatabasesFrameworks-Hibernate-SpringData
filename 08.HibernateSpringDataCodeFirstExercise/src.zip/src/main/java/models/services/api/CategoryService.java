package models.services.api;

import models.entities.Category;

public interface CategoryService {

    void saveCategory(Category category);
}
