package entities.ingredient.chemical;

import entities.ingredient.Ingredient;

public interface ChemicalIngredient extends Ingredient {
    String chemicalFormula();
}
