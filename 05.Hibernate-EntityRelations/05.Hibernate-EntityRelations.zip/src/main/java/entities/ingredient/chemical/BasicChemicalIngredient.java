package entities.ingredient.chemical;

import entities.ingredient.BasicIngredient;

public abstract class BasicChemicalIngredient extends BasicIngredient implements ChemicalIngredient {

}
