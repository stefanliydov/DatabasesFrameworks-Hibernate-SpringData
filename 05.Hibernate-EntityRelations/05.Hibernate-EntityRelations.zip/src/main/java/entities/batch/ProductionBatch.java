package entities.batch;

public class ProductionBatch {

}
