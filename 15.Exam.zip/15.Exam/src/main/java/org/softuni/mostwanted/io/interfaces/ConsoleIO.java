package org.softuni.mostwanted.io.interfaces;

public interface ConsoleIO {
    void write(String line);
}
