package app.retake;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetakeApplication {
	public static void main(String[] args) {
		SpringApplication.run(RetakeApplication.class, args);
	}
}
