package app.retake.io.api;

public interface ConsoleIO {
    void write(String line);
}
