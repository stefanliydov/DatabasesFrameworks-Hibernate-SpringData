package app.retake.controllers;

public class AnimalController {

    public String importDataFromJSON(String jsonContent) {
        return null;
    }

    public String exportAnimalsByOwnerPhoneNumber(String phoneNumber) {
        return null;
    }
}
