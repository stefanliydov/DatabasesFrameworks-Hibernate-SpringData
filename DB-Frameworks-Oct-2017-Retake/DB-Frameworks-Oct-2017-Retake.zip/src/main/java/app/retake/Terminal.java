package app.retake;

import app.retake.controllers.AnimalAidController;
import app.retake.io.api.FileIO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class Terminal implements CommandLineRunner {

    private final AnimalAidController animalAidController;
    private final FileIO fileIO;

    @Autowired
    public Terminal(AnimalAidController animalAidController, FileIO fileIO) {
        this.animalAidController = animalAidController;
        this.fileIO = fileIO;
    }

    @Override
    public void run(String... strings) throws Exception {
        this.animalAidController
                .importDataFromJSON(this.fileIO.read(Config.ANIMAL_AIDS_IMPORT_JSON));
    }
}
