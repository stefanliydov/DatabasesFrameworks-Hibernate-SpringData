package app.retake.domain.models;

import java.io.Serializable;

public class PassportAnimalId implements Serializable {

}
