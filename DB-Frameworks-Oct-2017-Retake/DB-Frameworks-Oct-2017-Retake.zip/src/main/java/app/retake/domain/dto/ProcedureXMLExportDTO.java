package app.retake.domain.dto;

public class ProcedureXMLExportDTO {

}
